drop database if exists AppStore;
create database AppStore;
use AppStore;
CREATE TABLE Developer
(
  developerName VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  contactNumber VARCHAR(15) NOT NULL,
  address TEXT NOT NULL,
  companyName VARCHAR(255) NOT NULL,
  registerDate DATE NOT NULL,
  developerId INT NOT NULL,
  PRIMARY KEY (developerId)
);

CREATE TABLE User
(
  userId INT NOT NULL,
  username VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  address TEXT NOT NULL,
  password VARCHAR(255) NOT NULL,
  firstName VARCHAR(255) NOT NULL,
  lastName VARCHAR(255) NOT NULL,
  createdDate DATE NOT NULL,
  status VARCHAR(50) NOT NULL,
  PRIMARY KEY (userId)
);

CREATE TABLE Subscription
(
  subscriptionId INT NOT NULL,
  userId INT NOT NULL,
  subscriptionDate DATE NOT NULL,
  expiryDate DATE NOT NULL,
  renew BOOLEAN NOT NULL,
  appId INT NOT NULL,
  PRIMARY KEY (subscriptionId),
  FOREIGN KEY (userId) REFERENCES User(userId)
);

CREATE TABLE Device
(
  deviceId INT NOT NULL,
  userId INT NOT NULL,
  deviceType VARCHAR(100) NOT NULL,
  deviceName VARCHAR(255) NOT NULL,
  serialNumber VARCHAR(100) NOT NULL,
  purchaseDate DATE NOT NULL,
  PRIMARY KEY (deviceId),
  FOREIGN KEY (userId) REFERENCES User(userId)
);

CREATE TABLE SupportTicket
(
  ticketId INT NOT NULL,
  userId INT NOT NULL,
  issueDescription TEXT NOT NULL,
  status VARCHAR(50) NOT NULL,
  createdDate DATE NOT NULL,
  PRIMARY KEY (ticketId),
  FOREIGN KEY (userId) REFERENCES User(userId)
);

CREATE TABLE Notification
(
  notificationId INT NOT NULL,
  userId INT NOT NULL,
  message TEXT NOT NULL,
  notificationDate DATE NOT NULL,
  readTime TIMESTAMP,
  PRIMARY KEY (notificationId),
  FOREIGN KEY (userId) REFERENCES User(userId)
);

CREATE TABLE Payment
(
  paymentId INT NOT NULL,
  userId INT NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  paymentDate DATE NOT NULL,
  paymentMethod VARCHAR(50) NOT NULL,
  PRIMARY KEY (paymentId),
  FOREIGN KEY (userId) REFERENCES User(userId)
);

CREATE TABLE OperatingSystem
(
  operatingSystemId INT NOT NULL,
  name VARCHAR(255) NOT NULL,
  version VARCHAR(50) NOT NULL,
  releaseDate DATE NOT NULL,
  deviceId INT NOT NULL,
  PRIMARY KEY (operatingSystemId),
  FOREIGN KEY (deviceId) REFERENCES Device(deviceId)
);

CREATE TABLE Category
(
  categoryId INT NOT NULL,
  categoryName VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  appId INT NOT NULL,
  PRIMARY KEY (categoryId)
);

CREATE TABLE WishList
(
  wishListId INT NOT NULL,
  userId INT NOT NULL,
  apps TEXT NOT NULL,
  PRIMARY KEY (wishListId),
  FOREIGN KEY (userId) REFERENCES User(userId)
);

CREATE TABLE App
(
  appId INT NOT NULL,
  appName VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  rating DECIMAL(3, 2) NOT NULL,
  releaseDate DATE NOT NULL,
  developerId INT NOT NULL,
  categoryId INT NOT NULL,
  subscriptionId INT NOT NULL,
  status VARCHAR(50) NOT NULL,
  PRIMARY KEY (appId),
  paymentId INT NOT NULL,
  FOREIGN KEY (developerId) REFERENCES Developer(developerId),
  FOREIGN KEY (categoryId) REFERENCES Category(categoryId),
  FOREIGN KEY (subscriptionId) REFERENCES subscription(subscriptionId),
  FOREIGN KEY (paymentId) REFERENCES payment(paymentId)
);

CREATE TABLE Review
(
  reviewId INT NOT NULL,
  userId INT NOT NULL,
  appId INT NOT NULL,
  rating DECIMAL(3, 2) NOT NULL,
  comments TEXT NOT NULL,
  dateOfReview DATE NOT NULL,
  PRIMARY KEY (reviewId),
  FOREIGN KEY (appId) REFERENCES App(appId),
  FOREIGN KEY (userId) REFERENCES User(userId)
);

CREATE TABLE Promotion
(
  promotionId INT NOT NULL,
  appId INT NOT NULL,
  discountPercentage DECIMAL(5, 2) NOT NULL,
  startDate DATE NOT NULL,
  endDate DATE NOT NULL,
  promotionCode VARCHAR(50) NOT NULL,
  description TEXT NOT NULL,
  PRIMARY KEY (promotionId),
  FOREIGN KEY (appId) REFERENCES App(appId)
);

CREATE TABLE LeaderBoard
(
  leaderBoardId INT NOT NULL,
  appId INT NOT NULL,
  score INT NOT NULL,
  ranks INT NOT NULL,
  dateAchieved DATE NOT NULL,
  PRIMARY KEY (leaderBoardId),
  FOREIGN KEY (appId) REFERENCES App(appId)
);

CREATE TABLE Download
(
  downloadId INT NOT NULL,
  userId INT NOT NULL,
  appId INT NOT NULL,
  downloadDate DATE NOT NULL,
  PRIMARY KEY (downloadId),
  FOREIGN KEY (userId) REFERENCES User(userId),
  FOREIGN KEY (appId) REFERENCES App(appId)
);

CREATE TABLE Advertisement
(
  advertisementId INT NOT NULL,
  appId INT NOT NULL,
  advertisementType VARCHAR(100) NOT NULL,
  startDate DATE NOT NULL,
  endDate DATE NOT NULL,
  description TEXT NOT NULL,
  PRIMARY KEY (advertisementId),
  FOREIGN KEY (appId) REFERENCES App(appId)
);

CREATE TABLE AppUpdate
(
  updateId INT NOT NULL,
  appId INT NOT NULL,
  updateVersion VARCHAR(50) NOT NULL,
  updateDate DATE NOT NULL,
  description TEXT NOT NULL,
  PRIMARY KEY (updateId),
  FOREIGN KEY (appId) REFERENCES App(appId)
);

CREATE TABLE AppVersion
(
  appVersionId INT NOT NULL,
  versionNumber VARCHAR(50) NOT NULL,
  releaseDate DATE NOT NULL,
  features TEXT NOT NULL,
  updateNotes TEXT NOT NULL,
  updateId INT NOT NULL,
  PRIMARY KEY (appVersionId),
  FOREIGN KEY (updateId) REFERENCES AppUpdate(updateId)
);

-- Inserting data into Developer table (Pakistani names and contact details)
INSERT INTO Developer (developerId, developerName, email, contactNumber, address, companyName, registerDate)
VALUES
(1, 'Ahmed Khan', 'ahmed.khan@example.com', '03011223344', '123 Lahore Rd, Lahore', 'TechWorks Pvt Ltd', '2022-01-01'),
(2, 'Sara Ali', 'sara.ali@example.com', '03123456789', '456 Karachi St, Karachi', 'Innovative Solutions', '2022-02-15'),
(3, 'Ali Raza', 'ali.raza@example.com', '03234567890', '789 Islamabad Ave, Islamabad', 'Creative Labs', '2022-03-20'),
(4, 'Faisal Ahmed', 'faisal.ahmed@example.com', '03456789012', '101 Faisal Town, Faisalabad', 'Global Enterprises', '2022-04-10'),
(5, 'Nida Sheikh', 'nida.sheikh@example.com', '03567890123', '202 Multan Rd, Multan', 'Tech Innovations', '2022-05-25'),
(6, 'Imran Ali', 'imran.ali@example.com', '03678901234', '303 Rawalpindi Rd, Rawalpindi', 'AppMasters Ltd', '2022-06-15'),
(7, 'Zainab Qureshi', 'zainab.qureshi@example.com', '03789012345', '404 Quetta Rd, Quetta', 'Smart Apps Inc', '2022-07-01'),
(8, 'Hassan Khan', 'hassan.khan@example.com', '03890123456', '505 Peshawar Ave, Peshawar', 'SoftWorks Pvt Ltd', '2022-08-10'),
(9, 'Ayesha Shah', 'ayesha.shah@example.com', '03901234567', '606 Sialkot Rd, Sialkot', 'DevHub Pvt Ltd', '2022-09-05'),
(10, 'Omer Javed', 'omer.javed@example.com', '04012345678', '707 Gujranwala Rd, Gujranwala', 'TechGiant Pvt Ltd', '2022-10-20');

-- Inserting data into User table (Pakistani names and contact details)
INSERT INTO User (userId, username, email, address, password, firstName, lastName, createdDate, status)
VALUES
(1, 'ahmedk01', 'ahmedk01@example.com', '1 Gulberg St, Lahore', 'password123', 'Ahmed', 'Khan', '2022-01-01', 'active'),
(2, 'sara_ali', 'sara.ali@example.com', '2 Karachi St, Karachi', 'password123', 'Sara', 'Ali', '2022-02-01', 'inactive'),
(3, 'ali_raza', 'ali.raza@example.com', '3 F-10, Islamabad', 'password123', 'Ali', 'Raza', '2022-03-01', 'active'),
(4, 'faisal_ahmed', 'faisal.ahmed@example.com', '4 Faisal Town, Faisalabad', 'password123', 'Faisal', 'Ahmed', '2022-04-01', 'active'),
(5, 'nida_sheikh', 'nida.sheikh@example.com', '5 DHA, Lahore', 'password123', 'Nida', 'Sheikh', '2022-05-01', 'inactive'),
(6, 'imran_ali', 'imran.ali@example.com', '6 Saddar, Rawalpindi', 'password123', 'Imran', 'Ali', '2022-06-01', 'active'),
(7, 'zainab_qureshi', 'zainab.qureshi@example.com', '7 Quetta Rd, Quetta', 'password123', 'Zainab', 'Qureshi', '2022-07-01', 'active'),
(8, 'hassan_khan', 'hassan.khan@example.com', '8 Peshawar Ave, Peshawar', 'password123', 'Hassan', 'Khan', '2022-08-01', 'inactive'),
(9, 'ayesha_shah', 'ayesha.shah@example.com', '9 Sialkot Rd, Sialkot', 'password123', 'Ayesha', 'Shah', '2022-09-01', 'active'),
(10, 'omer_javed', 'omer.javed@example.com', '10 Gujranwala Rd, Gujranwala', 'password123', 'Omer', 'Javed', '2022-10-01', 'active');


-- Inserting data into Subscription table
INSERT INTO Subscription (subscriptionId, userId, subscriptionDate, expiryDate, renew)
VALUES
(1, 1, '2022-01-01', '2023-01-01', true),
(2, 2, '2022-02-01', '2023-02-01', false),
(3, 3, '2022-03-01', '2023-03-01', true),
(4, 4,  '2022-04-01', '2023-04-01', true),
(5, 5, '2022-05-01', '2023-05-01', false),
(6, 6, '2022-06-01', '2023-06-01', true),
(7, 7, '2022-07-01', '2023-07-01', true),
(8, 8, '2022-08-01', '2023-08-01', false),
(9, 9, '2022-09-01', '2023-09-01', true),
(10, 10, '2022-10-01', '2023-10-01', false);

-- Inserting data into Device table
INSERT INTO Device (deviceId, userId, deviceType, deviceName, serialNumber, purchaseDate)
VALUES
(1, 1, 'Smartphone', 'Galaxy S21', 'ABC123456', '2022-01-10'),
(2, 2, 'Tablet', 'iPad Pro', 'DEF234567', '2022-02-10'),
(3, 3, 'Laptop', 'MacBook Air', 'GHI345678', '2022-03-10'),
(4, 4, 'Smartphone', 'iPhone 13', 'JKL456789', '2022-04-10'),
(5, 5, 'Smartwatch', 'Apple Watch Series 7', 'MNO567890', '2022-05-10'),
(6, 6, 'Smartphone', 'OnePlus 9', 'PQR678901', '2022-06-10'),
(7, 7, 'Tablet', 'Samsung Galaxy Tab S7', 'STU789012', '2022-07-10'),
(8, 8, 'Laptop', 'Dell XPS 13', 'VWX890123', '2022-08-10'),
(9, 9, 'Smartwatch', 'Fitbit Charge 5', 'YZA901234', '2022-09-10'),
(10, 10, 'Smartphone', 'Google Pixel 6', 'BCD012345', '2022-10-10');

-- Inserting data into SupportTicket table
INSERT INTO SupportTicket (ticketId, userId, issueDescription, status, createdDate)
VALUES
(1, 1, 'App crashes on startup', 'resolved', '2022-01-15'),
(2, 2, 'Unable to log in', 'pending', '2022-02-15'),
(3, 3, 'App not syncing data', 'resolved', '2022-03-15'),
(4, 4, 'Subscription renewal issue', 'pending', '2022-04-15'),
(5, 5, 'Device not pairing with app', 'resolved', '2022-05-15'),
(6, 6, 'Payment not going through', 'pending', '2022-06-15'),
(7, 7, 'Unable to download update', 'resolved', '2022-07-15'),
(8, 8, 'App slow on startup', 'pending', '2022-08-15'),
(9, 9, 'Error message on payment page', 'resolved', '2022-09-15'),
(10, 10, 'Unable to access subscription', 'pending', '2022-10-15');

-- Inserting data into Notification table
INSERT INTO Notification (notificationId, userId, message, notificationDate, readTime)
VALUES
(1, 1, 'New update available for your app', '2022-01-20', '2022-01-21 10:00:00'),
(2, 2, 'Your subscription is expiring soon', '2022-02-20', NULL),
(3, 3, 'Promo offer: 50% off on your next purchase', '2022-03-20', '2022-03-21 11:00:00'),
(4, 4, 'New feature added to your app', '2022-04-20', NULL),
(5, 5, 'System maintenance scheduled', '2022-05-20', '2022-05-21 14:00:00'),
(6, 6, 'Payment confirmation received', '2022-06-20', NULL),
(7, 7, 'App update available', '2022-07-20', '2022-07-21 15:00:00'),
(8, 8, 'Your account has been deactivated', '2022-08-20', NULL),
(9, 9, 'Security update required', '2022-09-20', '2022-09-21 12:00:00'),
(10, 10, 'Reminder: Subscription renewal', '2022-10-20', NULL);

-- Inserting data into Payment table
INSERT INTO Payment (paymentId, userId, amount, paymentDate, paymentMethod)
VALUES
(1, 1, 29.99, '2022-01-15', 'Credit Card'),
(2, 2, 49.99, '2022-02-15', 'PayPal'),
(3, 3, 19.99, '2022-03-15', 'Debit Card'),
(4, 4, 39.99, '2022-04-15', 'Credit Card'),
(5, 5, 59.99, '2022-05-15', 'PayPal'),
(6, 6, 25.99, '2022-06-15', 'Debit Card'),
(7, 7, 15.99, '2022-07-15', 'Credit Card'),
(8, 8, 9.99, '2022-08-15', 'PayPal'),
(9, 9, 39.99, '2022-09-15', 'Debit Card'),
(10, 10, 19.99, '2022-10-15', 'Credit Card');

-- Inserting data into OperatingSystem table
INSERT INTO OperatingSystem (operatingSystemId, name, version, releaseDate, deviceId)
VALUES
(1, 'Android', '11.0', '2022-01-01', 1),
(2, 'iOS', '15.0', '2022-02-01', 2),
(3, 'macOS', '11.2', '2022-03-01', 3),
(4, 'iOS', '14.0', '2022-04-01', 4),
(5, 'watchOS', '7.0', '2022-05-01', 5),
(6, 'Android', '12.0', '2022-06-01', 6),
(7, 'Android', '10.0', '2022-07-01', 7),
(8, 'Windows', '10', '2022-08-01', 8),
(9, 'watchOS', '8.0', '2022-09-01', 9),
(10, 'Android', '12.0', '2022-10-01', 10);

-- Inserting data into Category table
INSERT INTO Category (categoryId, categoryName, description, appId)
VALUES
(1, 'Productivity', 'Productivity apps to enhance work efficiency', 1),
(2, 'Health', 'Health and fitness apps', 2),
(3, 'Entertainment', 'Entertainment and media apps', 3),
(4, 'Education', 'Educational apps for learning', 4),
(5, 'Gaming', 'Mobile gaming apps', 5),
(6, 'Social', 'Social media and communication apps', 6),
(7, 'Finance', 'Finance and budgeting apps', 7),
(8, 'Travel', 'Travel and navigation apps', 8),
(9, 'Lifestyle', 'Lifestyle and well-being apps', 9),
(10, 'Utilities', 'Utility apps for system optimization', 10);

-- Inserting data into WishList table
INSERT INTO WishList (wishListId, userId, apps)
VALUES
(1, 1, '1,3,5'),
(2, 2, '2,6,7'),
(3, 3, '1,8,10'),
(4, 4, '3,4,9'),
(5, 5, '5,6,8'),
(6, 6, '2,7,10'),
(7, 7, '1,9,10'),
(8, 8, '4,6,8'),
(9, 9, '7,9,10'),
(10, 10, '3,5,6');

-- Inserting data into App table
INSERT INTO App (appId, appName, description, price, rating, releaseDate, developerId, categoryId, status,subscriptionId,paymentId)
VALUES
(1, 'TaskMaster', 'Task management and productivity app', 9.99, 4.5, '2022-01-01', 1, 1, 'active',1,1),
(2, 'FitTrack', 'Fitness tracker and health app', 4.99, 4.2, '2022-02-01', 2, 2, 'active',2,2),
(3, 'MovieHub', 'Streaming platform for movies', 0.00, 4.7, '2022-03-01', 3, 3, 'active',3,4),
(4, 'LearnNow', 'Education platform for online courses', 19.99, 4.6, '2022-04-01', 4, 4, 'active',4,3),
(5, 'BattleZone', 'Action-packed mobile game', 0.99, 4.3, '2022-05-01', 5, 5, 'active',5,6),
(6, 'SocialConnect', 'Connect with friends and family', 0.00, 4.4, '2022-06-01', 6, 6, 'active',7,5),
(7, 'BudgetWise', 'Track your finances and budgets', 7.99, 4.1, '2022-07-01', 7, 7, 'active',6,7),
(8, 'Wanderlust', 'Travel planning and navigation app', 5.99, 4.8, '2022-08-01', 8, 8, 'active',8,10),
(9, 'CalmLife', 'Meditation and mindfulness app', 0.00, 4.6, '2022-09-01', 9, 9, 'active',9,8),
(10, 'SpeedBooster', 'Optimize and speed up your device', 3.99, 4.3, '2022-10-01', 10, 10, 'active',10,9);

-- Inserting data into Review table
INSERT INTO Review (reviewId, userId, appId, rating, comments, dateOfReview)
VALUES
(1, 1, 1, 5.0, 'Great app, really helps with task management!', '2022-01-15'),
(2, 2, 2, 4.5, 'Helps me track my workouts and progress.', '2022-02-15'),
(3, 3, 3, 4.8, 'Great selection of movies!', '2022-03-15'),
(4, 4, 4, 4.7, 'The courses are top-notch!', '2022-04-15'),
(5, 5, 5, 4.2, 'Fun game, but needs more levels.', '2022-05-15'),
(6, 6, 6, 4.4, 'Good for staying connected with friends.', '2022-06-15'),
(7, 7, 7, 4.1, 'Helpful for tracking my expenses, but could improve UI.', '2022-07-15'),
(8, 8, 8, 5.0, 'Amazing for travel planning, highly recommend!', '2022-08-15'),
(9, 9, 9, 4.6, 'Really helps me relax and sleep better.', '2022-09-15'),
(10, 10, 10, 4.3, 'Speeded up my phone, but a little too many ads.', '2022-10-15');

-- Inserting data into Promotion table
INSERT INTO Promotion (promotionId, appId, discountPercentage, startDate, endDate, promotionCode, description)
VALUES
(1, 1, 20.0, '2022-01-01', '2022-02-01', 'NEWYEAR20', 'New Year Sale: 20% off'),
(2, 2, 15.0, '2022-02-01', '2022-03-01', 'FITSTART15', 'Get 15% off on all plans'),
(3, 3, 25.0, '2022-03-01', '2022-04-01', 'MOVIE25', 'Enjoy 25% off on your subscription'),
(4, 4, 30.0, '2022-04-01', '2022-05-01', 'LEARN30', '30% off on first course'),
(5, 5, 50.0, '2022-05-01', '2022-06-01', 'BATTLE50', '50% off on premium game purchase'),
(6, 6, 10.0, '2022-06-01', '2022-07-01', 'SOCIAL10', '10% off on new features'),
(7, 7, 5.0, '2022-07-01', '2022-08-01', 'BUDGET5', '5% off on premium plans'),
(8, 8, 20.0, '2022-08-01', '2022-09-01', 'TRAVEL20', '20% off on travel package'),
(9, 9, 10.0, '2022-09-01', '2022-10-01', 'CALM10', 'Get 10% off on premium membership'),
(10, 10, 15.0, '2022-10-01', '2022-11-01', 'BOOST15', '15% off on speed boosting features');


-- Inserting data into LeaderBoard table
INSERT INTO LeaderBoard (leaderBoardId, appId, score, ranks, dateAchieved)
VALUES
(1, 1, 1500, 1, '2022-01-15'),
(2, 2, 1200, 2, '2022-02-15'),
(3, 3, 1800, 1, '2022-03-15'),
(4, 4, 1400, 1, '2022-04-15'),
(5, 5, 1100, 2, '2022-05-15'),
(6, 6, 1000, 3, '2022-06-15'),
(7, 7, 900, 4, '2022-07-15'),
(8, 8, 1600, 1, '2022-08-15'),
(9, 9, 1100, 2, '2022-09-15'),
(10, 10, 1300, 2, '2022-10-15');

-- Inserting data into Download table
INSERT INTO Download (downloadId, userId, appId, downloadDate)
VALUES
(1, 1, 1, '2022-01-10'),
(2, 2, 2, '2022-02-10'),
(3, 3, 3, '2022-03-10'),
(4, 4, 4, '2022-04-10'),
(5, 5, 5, '2022-05-10'),
(6, 6, 6, '2022-06-10'),
(7, 7, 7, '2022-07-10'),
(8, 8, 8, '2022-08-10'),
(9, 9, 9, '2022-09-10'),
(10, 10, 10, '2022-10-10');

-- Inserting data into Advertisement table
INSERT INTO Advertisement (advertisementId, appId, advertisementType, startDate, endDate, description)
VALUES
(1, 1, 'Banner', '2022-01-01', '2022-01-31', 'Banner ad promoting TaskMaster app'),
(2, 2, 'Interstitial', '2022-02-01', '2022-02-28', 'Full-screen ad promoting FitTrack app'),
(3, 3, 'Video', '2022-03-01', '2022-03-31', 'Video ad promoting MovieHub app'),
(4, 4, 'Banner', '2022-04-01', '2022-04-30', 'Banner ad promoting LearnNow app'),
(5, 5, 'Interstitial', '2022-05-01', '2022-05-31', 'Full-screen ad promoting BattleZone app'),
(6, 6, 'Video', '2022-06-01', '2022-06-30', 'Video ad promoting SocialConnect app'),
(7, 7, 'Banner', '2022-07-01', '2022-07-31', 'Banner ad promoting BudgetWise app'),
(8, 8, 'Interstitial', '2022-08-01', '2022-08-31', 'Full-screen ad promoting Wanderlust app'),
(9, 9, 'Video', '2022-09-01', '2022-09-30', 'Video ad promoting CalmLife app'),
(10, 10, 'Banner', '2022-10-01', '2022-10-31', 'Banner ad promoting SpeedBooster app');

-- Inserting data into AppUpdate table
INSERT INTO AppUpdate (updateId, appId, updateVersion, updateDate, description)
VALUES
(1, 1, '1.1', '2022-01-15', 'Bug fixes and performance improvements'),
(2, 2, '2.0', '2022-02-15', 'New UI design and additional features'),
(3, 3, '1.2', '2022-03-15', 'New movie categories and streaming options'),
(4, 4, '1.1', '2022-04-15', 'Added new courses and updated content'),
(5, 5, '2.0', '2022-05-15', 'Added new levels and in-game purchases'),
(6, 6, '1.2', '2022-06-15', 'Added voice calling feature'),
(7, 7, '1.3', '2022-07-15', 'Improved UI and added expense categories'),
(8, 8, '1.0', '2022-08-15', 'Initial release of Wanderlust app'),
(9, 9, '1.1', '2022-09-15', 'Bug fixes and enhanced meditation features'),
(10, 10, '2.1', '2022-10-15', 'Improved speed optimization features');

-- Inserting data into AppVersion table
INSERT INTO AppVersion (appVersionId, versionNumber, releaseDate, features, updateNotes, updateId)
VALUES
(1, '1.1', '2022-01-20', 'Bug fixes, performance improvements', 'Fixed issues with notifications', 1),
(2, '2.0', '2022-02-20', 'New UI, additional tracking features', 'Redesigned the interface', 2),
(3, '1.2', '2022-03-20', 'New categories, better streaming options', 'Improved search functionality', 3),
(4, '1.1', '2022-04-20', 'Additional courses, updated content', 'Fixed broken links in courses', 4),
(5, '2.0', '2022-05-20', 'New levels, in-app purchases', 'Bug fixes for level progression', 5),
(6, '1.2', '2022-06-20', 'Voice calling, new chat features', 'Improved voice call quality', 6),
(7, '1.3', '2022-07-20', 'Enhanced expense tracking, new budget categories', 'Bug fixes and improvements', 7),
(8, '1.0', '2022-08-20', 'Initial version of the app', 'First release of the app', 8),
(9, '1.1', '2022-09-20', 'Enhanced meditation features', 'Improved session tracking', 9),
(10, '2.1', '2022-10-20', 'Speed optimization, new settings', 'Fixed bugs in optimization', 10);


-- 1. List all users, their devices, apps they have downloaded, and reviews for those apps

SELECT 
    U.username, 
    D.deviceName, 
    D.deviceType, 
    A.appName, 
    R.rating, 
    R.comments
FROM 
    User U
INNER JOIN Device D ON U.userId = D.userId
INNER JOIN Download Dn ON U.userId = Dn.userId
INNER JOIN App A ON Dn.appId = A.appId
INNER JOIN Review R ON A.appId = R.appId AND U.userId = R.userId;

-- 2  List all apps, their categories, user downloads, payments made, and reviews with ratings greater than 3
SELECT 
    A.appName, 
    C.categoryName, 
    COUNT(D.downloadId) AS downloadCount, 
    SUM(P.amount) AS totalPayment, 
    AVG(R.rating) AS averageRating
FROM 
    App A
INNER JOIN Category C ON A.categoryId = C.categoryId
INNER JOIN Download D ON A.appId = D.appId
INNER JOIN Payment P ON D.userId = P.userId
INNER JOIN Review R ON A.appId = R.appId
WHERE 
    R.rating > 3
GROUP BY 
    A.appName, C.categoryName;


-- 3 List users who have both downloaded apps in the "Gaming" category and made payments, along with app and payment details

SELECT 
    U.username, 
    A.appName, 
    C.categoryName, 
    P.paymentDate, 
    P.amount
FROM 
    User U
INNER JOIN Download D ON U.userId = D.userId
INNER JOIN App A ON D.appId = A.appId
INNER JOIN Category C ON A.categoryId = C.categoryId
INNER JOIN Payment P ON U.userId = P.userId
WHERE 
    C.categoryName = 'Gaming';

-- 4 Get the most popular apps (highest average ratings), their category, number of downloads, and promotion details

SELECT 
    A.appName, 
    C.categoryName, 
    AVG(R.rating) AS averageRating, 
    COUNT(D.downloadId) AS downloadCount, 
    P.promotionCode, 
    P.discountPercentage
FROM 
    App A
INNER JOIN Category C ON A.categoryId = C.categoryId
INNER JOIN Review R ON A.appId = R.appId
INNER JOIN Download D ON A.appId = D.appId
LEFT JOIN Promotion P ON A.appId = P.appId
GROUP BY 
    A.appName, C.categoryName, P.promotionCode;

-- 5 Get the top-rated apps that have BELOW  50 reviews, along with the developers' details and promotion information

SELECT 
    A.appName, 
    D.developerName, 
    AVG(R.rating) AS averageRating, 
    COUNT(R.reviewId) AS reviewCount, 
    P.promotionCode, 
    P.discountPercentage, 
    C.categoryName
FROM 
    App A
INNER JOIN Developer D ON A.developerId = D.developerId
INNER JOIN Review R ON A.appId = R.appId
LEFT JOIN Promotion P ON A.appId = P.appId
INNER JOIN Category C ON A.categoryId = C.categoryId
GROUP BY 
    A.appName, D.developerName, P.promotionCode, C.categoryName
HAVING 
    COUNT(R.reviewId) < 50 AND AVG(R.rating) > 4;

-- 6 Retrieve user details, including device information, subscription details, payment method, app details, 
-- review information, notifications, and support ticket issues for active users.
SELECT 
    U.userId, U.username, U.email, U.firstName, U.lastName, 
    D.deviceType, D.deviceName, D.purchaseDate,
    S.subscriptionDate, S.expiryDate, S.renew, 
    P.paymentMethod, P.amount, 
    A.appName, A.price, A.rating, A.releaseDate, 
    R.rating AS reviewRating, R.comments AS reviewComments,
    N.message AS notificationMessage,
    T.issueDescription AS supportTicketIssue
FROM 
    User U
    LEFT JOIN Device D ON U.userId = D.userId
    INNER JOIN Subscription S ON U.userId = S.userId
    LEFT JOIN Payment P ON U.userId = P.userId
    INNER JOIN Download DL ON U.userId = DL.userId
    RIGHT JOIN App A ON DL.appId = A.appId
    LEFT JOIN Review R ON U.userId = R.userId AND A.appId = R.appId
    LEFT JOIN Notification N ON U.userId = N.userId
    LEFT JOIN SupportTicket T ON U.userId = T.userId
WHERE 
    U.status = 'active'
ORDER BY 
    U.userId;
    -- 7 Retrieve the total payments made by each user where status is active
 SELECT u.username,(
    SELECT SUM(p.amount) 
    FROM Payment p 
    WHERE p.userId = u.userId
) AS totalPayment 
FROM User u 
WHERE u.status = 'active'
order by u.username desc;
-- 8 Find all apps with a rating higher than 4.0 along with their names and prices where discount percentage greater than 10
SELECT a.appName, a.price, a.rating 
FROM App AS a 
WHERE a.rating > 4.0 
  AND a.appId IN (
    SELECT appId 
    FROM Promotion 
    WHERE discountPercentage > 10
  );
-- 9  Retrieve the leaderboard rankings for apps released after 2022-01-01 and discountpercentage is greater than 0
SELECT l.ranks, l.score, a.appName 
FROM LeaderBoard l 
JOIN App a ON l.appId = a.appId 
WHERE a.releaseDate > '2022-01-01' 
  AND l.appId IN (
    SELECT appId 
    FROM Promotion 
    WHERE discountPercentage > 0
  );
  -- 10 calculates the total revenue earned from the 'MovieHub' app, along with the developer's name and email.
SELECT d.developerName,d.email, SUM(a.price) AS total_revenue
FROM Developer d
inner JOIN App a
 ON d.developerId = a.developerId
WHERE a.appName LIKE '%MovieHub%' 
GROUP BY d.developerName;
-- 11  retrieves the username, address, and status of users whose userId is associated with developers from the company 'Global Enterprises'.
SELECT u.username,u.address,u.status
FROM User u
WHERE u.userId IN (
    SELECT developerId
    FROM Developer
    WHERE companyName = 'Global Enterprises'
);
-- 12  List all apps with their names, prices, and the number of reviews received, along with the developer's email address
SELECT a.appName, a.price, COUNT(r.reviewId) as review_count, d.email
FROM App a
INNER JOIN Developer d ON a.developerId = d.developerId
JOIN Review r ON a.appId = r.appId
GROUP BY a.appName, a.price, d.email;


-- 13retrieves the names of developers and counts the number of apps they have, but only for developers who have more than 5 apps listed
SELECT d.developerName, COUNT(a.appId) AS total_apps
FROM Developer d
JOIN App a ON d.developerId = a.developerId
where a.appId > 5
GROUP BY d.developerName;
-- 14 uery finds the total revenue generated by each developer from apps with names containing 'MovieHub
SELECT d.developerName, SUM(a.price) AS total_revenue
FROM Developer d
JOIN App a ON d.developerId = a.developerId
WHERE a.appName LIKE '%MovieHub%'
GROUP BY d.developerName;

-- 15 query selects the category name and the total number of downloads for each category, ordering the results by the total downloads in descending order.
SELECT CategoryName, TotalDownloads
FROM (SELECT 
         c.CategoryName, 
         COUNT(d.DownloadID) AS TotalDownloads
         FROM Category c
     JOIN App a ON c.CategoryID = a.CategoryID
     JOIN Download d ON a.AppID = d.AppID
     GROUP BY c.CategoryName
     ORDER BY TotalDownloads DESC )AS TopCategories;
-- 16 Retrieve the total number of downloads, average rating, and total payments for apps released after January 1, 2020, grouped by developer and app name.
SELECT 
    D.developerName, 
    A.appName, 
    COUNT(DL.downloadId) AS totalDownloads, 
    AVG(R.rating) AS averageRating, 
    SUM(P.amount) AS totalPayments
FROM 
    Developer D
INNER JOIN App A ON D.developerId = A.developerId
INNER JOIN Download DL ON A.appId = DL.appId
INNER JOIN Review R ON A.appId = R.appId
INNER JOIN Payment P ON DL.userId = P.userId
WHERE 
    A.releaseDate > '2020-01-01'
GROUP BY 
    D.developerName, A.appName;
-- 17  List all users, their devices, apps they have downloaded, and reviews for those apps
SELECT 
    U.username, 
    D.deviceName, 
    D.deviceType, 
    A.appName, 
    R.rating, 
    R.comments
FROM 
    User U
INNER JOIN Device D ON U.userId = D.userId
INNER JOIN Download Dn ON U.userId = Dn.userId
INNER JOIN App A ON Dn.appId = A.appId
INNER JOIN Review R ON A.appId = R.appId AND U.userId = R.userId;
-- 18 Get the most popular apps (highest average ratings), their category, number of downloads, and promotion details.
SELECT 
    A.appName, 
    C.categoryName, 
    AVG(R.rating) AS averageRating, 
    COUNT(D.downloadId) AS downloadCount, 
    P.promotionCode, 
    P.discountPercentage
FROM 
    App A
INNER JOIN Category C ON A.categoryId = C.categoryId
INNER JOIN Review R ON A.appId = R.appId
INNER JOIN Download D ON A.appId = D.appId
LEFT JOIN Promotion P ON A.appId = P.appId
GROUP BY 
    A.appName, C.categoryName, P.promotionCode;

